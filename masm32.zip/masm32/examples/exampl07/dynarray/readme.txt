These 5 examples were used in the development of the dynamic array capacity
built into version 10 of MASM32. The test pieces show many of the macro functions
that are built into the dynamic array system.