pproc.exe
---------

This tool creates an array of prime numbers in reverse order for fast hash
table bucket calculation.